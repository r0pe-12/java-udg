//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {

    GUI gui = new GUI();
    gui.setVisible(true);
//    ArrayList<Tiket> tiketi = Tiket.getAll();
//    System.out.println(tiketi.getFirst().getBroj_tiketa());
//    tiketi.add(new Tiket("BPCA164", LocalDateTime.now(), TipVozila.AUTOMOBIL));
}
