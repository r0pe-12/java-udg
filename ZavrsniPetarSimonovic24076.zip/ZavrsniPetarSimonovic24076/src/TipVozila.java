public enum TipVozila {
    AUTOMOBIL, KOMBI, AUTOBUS
}
